module.exports = [
  {
    "phase": 1,
    "betAmount": 0.01022,
    "netProfit": 0.00971
  },
  {
    "phase": 2,
    "betAmount": 0.0283,
    "netProfit": 0.01667
  },
  {
    "phase": 3,
    "betAmount": 0.07839,
    "netProfit": 0.03595
  },
  {
    "phase": 4,
    "betAmount": 0.21713,
    "netProfit": 0.08937
  },
  {
    "phase": 5,
    "betAmount": 0.60146,
    "netProfit": 0.23735
  },
  {
    "phase": 6,
    "betAmount": 1.66605,
    "netProfit": 0.64725
  },
  {
    "phase": 7,
    "betAmount": 4.61497,
    "netProfit": 1.78267
  },
  {
    "phase": 8,
    "betAmount": 12.78347,
    "netProfit": 4.92777
  }
];
