module.exports = {
  betAmount: 100,
  phaseStages: 8,
};
