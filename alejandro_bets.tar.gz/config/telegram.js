module.exports = {
  apiId: 28312009,
  apiHash: 'e8ec84155cd1f72a384b0bf741c13cc9',
  phoneNumber: '+34617845309',
  password: 'Hammer12345',
  signalChannel: 'BTC_60s_prediction'
};