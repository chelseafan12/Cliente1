module.exports = {
  webUrl: "https://coinryze.org",
  email: 'alejandromartintablada7@gmail.com',
  password: 'Youtube123',
  calculatorUrl: "https://finance.coinryze.org",
};
